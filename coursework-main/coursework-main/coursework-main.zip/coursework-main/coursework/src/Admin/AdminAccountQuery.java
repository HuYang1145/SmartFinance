package Admin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AdminAccountQuery extends JFrame {
    private JButton queryButton;
    private JTable accountTable;
    private NonEditableTableModel tableModel; // 使用自定义的 TableModel

    // 自定义 TableModel，禁止编辑
    private static class NonEditableTableModel extends DefaultTableModel {
        public NonEditableTableModel(Object[] columnNames, int rowCount) {
            super(columnNames, rowCount);
        }

        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // 禁用所有单元格的编辑
        }
    }

    public AdminAccountQuery() {
        setTitle("管理员账户管理");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // 创建查询按钮
        queryButton = new JButton("查询已注册的用户");

        // 创建表格模型
        String[] columnNames = {"用户名", "密码", "手机号", "邮箱", "性别", "地址", "创建时间", "账号状态", "账户类型", "金额"};
        tableModel = new NonEditableTableModel(columnNames, 0); // 使用自定义的 TableModel
        accountTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(accountTable);

        // 查询按钮监听事件
        queryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showRegisteredUsers();
            }
        });

        // 布局设置
        setLayout(new BorderLayout());
        add(queryButton, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }

    private void showRegisteredUsers() {
        tableModel.setRowCount(0);

        try (BufferedReader reader = new BufferedReader(new FileReader("accounts.csv"))) {
            String line = reader.readLine(); // 读取并跳过表头
            if (line == null) {
                JOptionPane.showMessageDialog(this, "accounts.csv 文件为空！", "提示", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 10) {
                    tableModel.addRow(parts);
                } else {
                    System.out.println("无效数据行: " + line + ". 期望 10 个字段，但找到 " + parts.length + " 个。");
                }
            }

            // 设置 "创建时间" 列的宽度
            TableColumnModel columnModel = accountTable.getColumnModel();
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                if (tableModel.getColumnName(i).equals("创建时间")) {
                    TableColumn creationTimeColumn = columnModel.getColumn(i);
                    creationTimeColumn.setPreferredWidth(150); // 设置一个较大的宽度，你可以根据实际情况调整
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "读取 accounts.csv 文件时发生错误！", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new AdminAccountQuery();
    }
}